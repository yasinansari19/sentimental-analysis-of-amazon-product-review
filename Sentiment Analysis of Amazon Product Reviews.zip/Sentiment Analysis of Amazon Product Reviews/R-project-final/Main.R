library(dplyr)
library(stringi)
library(tm)
library(tidytext)
library(wordcloud)
library(ggplot2)
library(tidyr)
library(mgsub)
library(scales) 
library(stringr)
library(textdata)
library(widyr)

amazon.reviews <- read.csv("C:/Users/Andy/Documents/R-project-final/product_reviews.csv")

# You can save the data set for later use
save(amazon.reviews, file = "C:/Users/Andy/Documents/R-project-final/amazon.reviews.RData")

# You can load the saved data with the following code 
load("C:/Users/Andy/Documents/R-project-final/amazon.reviews.RData")

# Ignore the reviewers that didn't buy the product. 
# Verified_Purchase should be TRUE
amazon.reviews <- filter(amazon.reviews, Verified_Purchase==TRUE)

# Clean the reviews text, prepare for analysis.----
#			 

# Load "Stop Words" from the tidytext package
data("stop_words")

amazon.reviews.text <- amazon.reviews %>%
  select(reviewText)

# Encoding
# Check Encoding and Make it consistent
stri_enc_mark(amazon.reviews.text$reviewText)
amazon.reviews.text$reviewText <- sapply(amazon.reviews.text$reviewText,
                                                  function(row) iconv(row,
                                                                      "latin1",
                                                                      "ASCII",
                                                                      sub = " "))


# Lowecase all text
amazon.reviews.text$reviewText <- tolower(amazon.reviews.text$reviewText)

# make wasn't=was not, can't=can not, etc..
amazon.reviews.text$reviewText <- gsub("wasn[\u2019']t", "was not", amazon.reviews.text$reviewText)
amazon.reviews.text$reviewText <- gsub("won[\u2019']t", "will not", amazon.reviews.text$reviewText)
amazon.reviews.text$reviewText <- gsub("can[\u2019']t", "can not", amazon.reviews.text$reviewText)
amazon.reviews.text$reviewText <- gsub("didn[\u2019']t", "did not", amazon.reviews.text$reviewText)
amazon.reviews.text$reviewText <- gsub("don[\u2019']t", "do not", amazon.reviews.text$reviewText)
amazon.reviews.text$reviewText <- gsub("I[\u2019']m", "I am", amazon.reviews.text$reviewText)
amazon.reviews.text$reviewText <- gsub("[\u2019']ve", " have", amazon.reviews.text$reviewText) 
amazon.reviews.text$reviewText <- gsub("[\u2019|']s", "", amazon.reviews.text$reviewText)
amazon.reviews.text$reviewText <- gsub("[\u2019']re", " are", amazon.reviews.text$reviewText)
amazon.reviews.text$reviewText <- gsub("[\u2019']ll", " will", amazon.reviews.text$reviewText)

# If you view common typos during your analysis, fix them here.
amazon.reviews.text$reviewText<- gsub("canceling", "cancelling", amazon.reviews.text$reviewText)
amazon.reviews.text$reviewText <- gsub("cancellation", "cancelling", amazon.reviews.text$reviewText)


# omit the following two lines if you have not loaded the tm package
# Remove numbers in the text
amazon.reviews.text$reviewText <- removeNumbers(amazon.reviews.text$reviewText)
# Remove punctuations in the text
amazon.reviews.text$reviewText <- removePunctuation(amazon.reviews.text$reviewText)

# Fix Negations
# Create a list to identify the sentiment shifters in the text
negation.words <- c("not",
                    "no",
                    "without",
                    "never",
                    "bad",
                    "none",
                    "never",
                    "nobody",
                    "nowhere",
                    "neither",
                    "nothing"
)


shifted.words <- amazon.reviews.text %>%
  unnest_tokens(bigram, reviewText, token = "ngrams", n = 2)%>%
  count(bigram, sort = TRUE) %>%
  separate(bigram, c("word1", "word2"), sep = " ")%>%
  filter(word1 %in% negation.words & !word2 %in% stop_words$word)%>%
  inner_join(get_sentiments("bing"), by = c(word2 = "word"))%>%
  mutate(sentiment = ifelse(sentiment == "positive", 1, -1)) %>%
  mutate(score = sentiment * n) %>%
  mutate(word2 = reorder(word2, score))

shifted.words

# Pick the most effective sentiment shifters
negated.phrases <- c("not worth", 
                     "not noise",
                     "no issues",
                     "no complaints",
                     "not disappoint",
                     "not disappointed",
                     "not cheap",
                     "no regrets"
                     
)

# Find synonyms for the phrases above to replace
synonyms <- c("expensive",
              "functional",
              "cool",
              "satisfied",
              "satisfied",
              "satisfied",
              "expensive",
              "satisfied"
)

# Replace the negations with their synonyms.
amazon.reviews.text <- mgsub(amazon.reviews.text$reviewText, negated.phrases, synonyms) %>%
  dplyr::as_tibble() %>%
  rename(reviewText = value)

# if you want to ignore words that are frequent but doesn't help, add them to this list.
ignore.words <- tibble(word = c("sound", "bose", "headphones","noise", "soundlink"))

# create the words freq table
word.freq.table<- amazon.reviews.text %>% 
  unnest_tokens(word, reviewText) %>%
  anti_join(stop_words) %>%
  anti_join(ignore.words) %>%
  count(word, sort = TRUE)
word.freq.table


# Plotting a Wordcloud
word.freq.table %>% 
  filter(n>40) %>%
  with(wordcloud(word, n,
                 scale = c(5,0.5),
                 colors = brewer.pal(8, "Dark2")))

# Most Common Bigrams
amazon.reviews.text %>%
  unnest_tokens(bigram, reviewText, token = "ngrams", n = 2) %>%
  count(bigram, sort = TRUE) %>%
  separate(bigram, c("word1", "word2"), sep = " ") %>%
  filter(!word1 %in% stop_words$word & !word2 %in% stop_words$word) %>%
  filter(n>7) %>%
  unite(word, word1:word2, sep = " ") %>%
  with(wordcloud(word, n,
                 scale = c(3,0.7),
                 colors = brewer.pal(8, "Dark2")))

# Most common Positive and Negative words using Bing
amazon.reviews.text %>% 
  unnest_tokens(word, reviewText) %>%
  anti_join(stop_words) %>%
  anti_join(ignore.words) %>%
  inner_join(get_sentiments("bing")) %>%
  count(word, sentiment, sort = TRUE) %>%
  filter(n > 20) %>%
  mutate(word = reorder(word, n)) %>%
  mutate(percent = round(n/sum(n), 3)) %>%
  ggplot(aes(x = word, y = percent, fill = sentiment, label = percent)) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~sentiment, scales = "free_y") +
  geom_text(aes(y = 0.7*percent)) +
  labs(title = "Amazon Product Reviews Word Polarity (bing)") +
  coord_flip() + 
  theme_bw() +
  theme(plot.title = element_text(hjust = 0.5))
